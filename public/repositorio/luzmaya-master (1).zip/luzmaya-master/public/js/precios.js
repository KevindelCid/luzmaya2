function precio(){

alert('se cambio el valor del precio');



}