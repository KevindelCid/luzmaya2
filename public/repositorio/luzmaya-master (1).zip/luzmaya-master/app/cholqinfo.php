<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class cholqinfo extends Model
{
    //
    protected $tabla = 'cholqinfos';
}

