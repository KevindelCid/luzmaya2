<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nawal extends Model
{
    // aqui vamos a referenciar los modelos de cada una de las tablasp
    protected $tabla = 'nawales';
}
