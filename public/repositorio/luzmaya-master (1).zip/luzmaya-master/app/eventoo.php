<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class eventoo extends Model
{
    //
}
