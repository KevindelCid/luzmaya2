<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ajqij extends Model
{
    //
}
