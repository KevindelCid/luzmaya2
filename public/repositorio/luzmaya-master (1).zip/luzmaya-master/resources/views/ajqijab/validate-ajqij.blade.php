
@extends('layouts.app')
@section('content')
    <div class="container">

<h3>¡Se ha enviado su solicitud!</h3>
<h5>Se le notificará cuando exista un resultado.</h5>


    </div>
    
    @endsection('layouts.app') 